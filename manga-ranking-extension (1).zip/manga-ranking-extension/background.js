// ===== ターゲット定義 =====
const TARGETS = [
  { key:"piccoma_fantasy_daily", svc:"piccoma", label:"ピッコマ ファンタジー", url:"https://piccoma.com/web/ranking/K/P/2", genre:"ファンタジー", period:"daily", wait:6000 },
  { key:"piccoma_action_daily",  svc:"piccoma", label:"ピッコマ アクション",   url:"https://piccoma.com/web/ranking/K/P/5", genre:"アクション",   period:"daily", wait:6000 },
  { key:"piccoma_romance_daily", svc:"piccoma", label:"ピッコマ 恋愛",         url:"https://piccoma.com/web/ranking/K/P/1", genre:"恋愛",         period:"daily", wait:6000 },
  { key:"piccoma_bl_daily",      svc:"piccoma", label:"ピッコマ BL",           url:"https://piccoma.com/web/ranking/K/P/14", genre:"BL",          period:"daily", wait:6000 },
  { key:"piccoma_tl_daily",      svc:"piccoma", label:"ピッコマ TL",           url:"https://piccoma.com/web/ranking/K/P/13", genre:"TL",          period:"daily", wait:6000 },
  { key:"seymour_shounen_daily",   svc:"seymour", label:"シーモア 少年 日間", url:"https://www.cmoa.jp/search/purpose/ranking/boy/",                    genre:"少年", period:"daily",   wait:2000 },
  { key:"seymour_seinen_daily",    svc:"seymour", label:"シーモア 青年 日間", url:"https://www.cmoa.jp/search/purpose/ranking/gentle/",                 genre:"青年", period:"daily",   wait:2000 },
  { key:"seymour_shoujo_daily",    svc:"seymour", label:"シーモア 少女 日間", url:"https://www.cmoa.jp/search/purpose/ranking/girl/",                   genre:"少女", period:"daily",   wait:2000 },
  { key:"seymour_josei_daily",     svc:"seymour", label:"シーモア 女性 日間", url:"https://www.cmoa.jp/search/purpose/ranking/lady/",                   genre:"女性", period:"daily",   wait:2000 },
  { key:"seymour_bl_daily",        svc:"seymour", label:"シーモア BL 日間",   url:"https://www.cmoa.jp/search/purpose/ranking/boyslove/",               genre:"BL",   period:"daily",   wait:2000 },
  { key:"seymour_tl_daily",        svc:"seymour", label:"シーモア TL 日間",   url:"https://www.cmoa.jp/search/purpose/ranking/teenslove/",              genre:"TL",   period:"daily",   wait:2000 },
  { key:"seymour_shounen_monthly", svc:"seymour", label:"シーモア 少年 月間", url:"https://www.cmoa.jp/search/purpose/ranking/boy/?period=monthly",     genre:"少年", period:"monthly", wait:2000 },
  { key:"seymour_seinen_monthly",  svc:"seymour", label:"シーモア 青年 月間", url:"https://www.cmoa.jp/search/purpose/ranking/gentle/?period=monthly",  genre:"青年", period:"monthly", wait:2000 },
  { key:"seymour_shoujo_monthly",  svc:"seymour", label:"シーモア 少女 月間", url:"https://www.cmoa.jp/search/purpose/ranking/girl/?period=monthly",    genre:"少女", period:"monthly", wait:2000 },
  { key:"seymour_josei_monthly",   svc:"seymour", label:"シーモア 女性 月間", url:"https://www.cmoa.jp/search/purpose/ranking/lady/?period=monthly",    genre:"女性", period:"monthly", wait:2000 },
  { key:"seymour_bl_monthly",      svc:"seymour", label:"シーモア BL 月間",   url:"https://www.cmoa.jp/search/purpose/ranking/boyslove/?period=monthly",genre:"BL",   period:"monthly", wait:2000 },
  { key:"seymour_tl_monthly",      svc:"seymour", label:"シーモア TL 月間",   url:"https://www.cmoa.jp/search/purpose/ranking/teenslove/?period=monthly",genre:"TL",  period:"monthly", wait:2000 },
];

// ニコニコのデフォルトURL（ジャンル→URL）
const NICONICO_DEFAULT_URLS = {
  shounen: { daily:"https://manga.nicovideo.jp/ranking/point/daily/shonen",   monthly:"https://manga.nicovideo.jp/ranking/point/monthly/shonen" },
  seinen:  { daily:"https://manga.nicovideo.jp/ranking/point/daily/seinen",   monthly:"https://manga.nicovideo.jp/ranking/point/monthly/seinen" },
  shoujo:  { daily:"https://manga.nicovideo.jp/ranking/point/daily/shojo",    monthly:"https://manga.nicovideo.jp/ranking/point/monthly/shojo" },
  josei:   { daily:"https://manga.nicovideo.jp/ranking/point/daily/josei",    monthly:"https://manga.nicovideo.jp/ranking/point/monthly/josei" },
  // bl/tl: ニコニコ漫画にはBL・TLジャンルがないため対象外
};

const GENRE_LABEL_MAP = { shounen:"少年", seinen:"青年", shoujo:"少女", josei:"女性", bl:"BL", tl:"TL" };
const PERIOD_LABEL_MAP = { daily:"日間", monthly:"月間" };

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "START_FETCH") {
    chrome.storage.local.get(["running"], d => {
      if (d.running) { sendResponse({ ok:false, reason:"already_running" }); return; }
      sendResponse({ ok:true });
      const opts = {
        limit: msg.limit || 30,
        fetchDetail: !!msg.fetchDetail,
      };
      runAll(msg.selectedKeys||[], msg.rentaUrls||{}, msg.niconicoConfig||{}, opts);
    });
    return true;
  }
});

async function runAll(selectedKeys, rentaUrls, niconicoConfig, opts) {
  _statuses = {};
  const { limit, fetchDetail } = opts;
  const targets = TARGETS.filter(t => selectedKeys.includes(t.key));

  // Renta! 動的ターゲット
  const dynamicTargets = [];
  for (const [key, url] of Object.entries(rentaUrls)) {
    if (!url || !url.trim()) continue;
    const parts = key.split('_');
    const period = parts[parts.length-1];
    const genre  = parts.slice(1,-1).join('_');
    dynamicTargets.push({
      key, svc:"renta",
      label:`Renta! ${GENRE_LABEL_MAP[genre]||genre} ${PERIOD_LABEL_MAP[period]||period}`,
      url:url.trim(), genre:GENRE_LABEL_MAP[genre]||genre, period, wait:3000
    });
  }

  // ニコニコ 動的ターゲット（チェックされたジャンル×期間）
  for (const [genre, periods] of Object.entries(niconicoConfig)) {
    for (const period of periods) {
      const url = NICONICO_DEFAULT_URLS[genre]?.[period];
      if (!url) continue;
      const key = `niconico_${genre}_${period}`;
      dynamicTargets.push({
        key, svc:"niconico",
        label:`ニコニコ ${GENRE_LABEL_MAP[genre]||genre} ${PERIOD_LABEL_MAP[period]||period}`,
        url, genre:GENRE_LABEL_MAP[genre]||genre, period, wait:3000
      });
    }
  }

  const allTargets = [...targets, ...dynamicTargets];
  const total = allTargets.length;
  await chrome.storage.local.set({ running:true, step:0, total, msg:"開始...", statuses:{}, lastResult:null });
  const result = {};
  let step = 0;

  for (const t of allTargets) {
    step++;
    await patchStatus(t.key, "取得中...", "ing");
    await chrome.storage.local.set({ step, msg: t.label + " 取得中..." });
    try {
      let items;
      if (t.svc === "renta") {
        items = await fetchRenta(t.url, t.genre, t.period, limit, fetchDetail);
      } else {
        items = await fetchOne(t.url, t.svc, t.genre, t.period, t.wait, limit, fetchDetail);
      }
      result[t.key] = items;
      await patchStatus(t.key, items.length+"件", items.length>0?"ok":"warn");
    } catch(e) {
      result[t.key] = [];
      await patchStatus(t.key, "失敗", "err");
    }
    await sleep(1200);
  }
  await chrome.storage.local.set({ running:false, step:total, msg:"完了！", lastResult:result });
}

// ===== Renta! ページング対応 =====
async function fetchRenta(startUrl, genre, period, limit, fetchDetail) {
  const all = [];
  const tab = await chrome.tabs.create({ url:startUrl, active:false });
  await waitLoad(tab.id);
  await sleep(3000);
  let pageCount = 0;
  while (all.length < limit && pageCount < 5) {
    pageCount++;
    try {
      const res = await chrome.scripting.executeScript({
        target:{ tabId:tab.id }, func:scrapeRentaPage, args:[genre, period, all.length, limit]
      });
      const { items, nextUrl } = res?.[0]?.result || { items:[], nextUrl:null };
      for (const it of items) { if (all.length >= limit) break; all.push(it); }
      if (!nextUrl || all.length >= limit) break;
      await chrome.scripting.executeScript({ target:{ tabId:tab.id }, func:(u)=>{ window.location.href=u; }, args:[nextUrl] });
      await waitLoad(tab.id);
      await sleep(2500);
    } catch(e) { break; }
  }
  chrome.tabs.remove(tab.id).catch(()=>{});

  // 出版社・レーベル取得（fetchDetail=true のとき、各作品詳細ページを開く）
  if (fetchDetail && all.length > 0) {
    for (const it of all) {
      if (!it._detailUrl) continue;
      try {
        const dtab = await chrome.tabs.create({ url:it._detailUrl, active:false });
        await waitLoad(dtab.id);
        await sleep(1500);
        const dres = await chrome.scripting.executeScript({ target:{ tabId:dtab.id }, func:scrapeRentaDetail });
        const detail = dres?.[0]?.result || {};
        it.publisher = detail.publisher||"";
        it.label     = detail.label||"";
        chrome.tabs.remove(dtab.id).catch(()=>{});
      } catch(e) { it.publisher=""; it.label=""; }
      delete it._detailUrl;
      await sleep(800);
    }
  } else {
    for (const it of all) { delete it._detailUrl; }
  }
  return all;
}

function scrapeRentaPage(genre, period, startRank, limit) {
  function clean(t) { return (t||"").replace(/\s+/g," ").trim(); }
  const SKIP = new Set(["カート","検索","お知らせ","マイページ","ログイン","無料会員登録","ポイント購入","ヘルプ","トップ","ランキング","新着","お得","雑誌","タテコミ｜話","マンガ｜話","マンガ｜巻","作品詳細","タテコミ｜巻","続きを読む","もっと見る","試し読み","立ち読み","購入","レンタル","お気に入り"]);
  const items = []; const seen = new Set();
  document.querySelectorAll("a[href*='/renta/sc/frm/item/']").forEach(a => {
    if (items.length >= limit) return;
    const t = clean(a.textContent || a.getAttribute("title") || "");
    if (!t || t.length < 2 || t.length > 120 || seen.has(t) || SKIP.has(t)) return;
    if (/^[\d\s,.・▼▲]+$/.test(t)) return;
    if (t.includes("｜話") || t.includes("｜巻")) return;
    seen.add(t);
    const container = a.closest("li") || a.closest("div[class]") || a.parentElement;
    const authorLink = container && container.querySelector("a[href*='author']");
    const author = authorLink ? clean(authorLink.textContent) : "";
    items.push({ rank:startRank+items.length+1, title:t, author, genre, period, publisher:"", label:"", tags:[], trend:"same", _detailUrl:a.href });
  });
  let nextUrl = null;
  const nextLinks = [...document.querySelectorAll("a")].filter(a => ["次へ","次のページ",">","›"].includes((a.textContent||"").trim()));
  if (nextLinks.length > 0) {
    const href = nextLinks[0].getAttribute("href");
    if (href) nextUrl = href.startsWith("http") ? href : "https://renta.papy.co.jp"+href;
  }
  return { items, nextUrl };
}

function scrapeRentaDetail() {
  function clean(t) { return (t||"").replace(/\s+/g," ").trim(); }
  let publisher = "", label = "";
  // 出版社: 「出版社：」テキストの近くのリンク
  const allText = document.body.innerText || "";
  const pubM = allText.match(/出版社[：:]\s*([^\n\r]{2,40})/);
  if (pubM) publisher = pubM[1].trim();
  const labM = allText.match(/レーベル[：:]\s*([^\n\r]{2,40})/);
  if (labM) label = labM[1].trim();
  // フォールバック：パンくずや定義リスト
  if (!publisher) {
    const pubLink = document.querySelector("a[href*='publisher']");
    if (pubLink) publisher = clean(pubLink.textContent);
  }
  if (!label) {
    const labLink = document.querySelector("a[href*='magazine'],a[href*='label']");
    if (labLink) label = clean(labLink.textContent);
  }
  return { publisher, label };
}

// ===== 汎用スクレイパー =====
async function fetchOne(url, svc, genre, period, waitMs, limit, fetchDetail) {
  const tab = await chrome.tabs.create({ url, active:false });
  await waitLoad(tab.id);
  await sleep(waitMs||3000);
  let items = [];
  try {
    const res = await chrome.scripting.executeScript({ target:{ tabId:tab.id }, func:scrape, args:[svc, genre, period, limit] });
    items = res?.[0]?.result || [];
  } finally {
    chrome.tabs.remove(tab.id).catch(()=>{});
  }

  // シーモア：fetchDetail ON なら各作品ページから出版社・レーベル取得
  if (svc === "seymour" && fetchDetail && items.length > 0) {
    for (const it of items) {
      if (!it._detailUrl) continue;
      try {
        const dtab = await chrome.tabs.create({ url:it._detailUrl, active:false });
        await waitLoad(dtab.id);
        await sleep(1500);
        const dres = await chrome.scripting.executeScript({ target:{ tabId:dtab.id }, func:scrapeSeymourDetail });
        const detail = dres?.[0]?.result || {};
        it.publisher = detail.publisher||"";
        it.label     = detail.label||"";
        chrome.tabs.remove(dtab.id).catch(()=>{});
      } catch(e) { it.publisher=""; it.label=""; }
      delete it._detailUrl;
      await sleep(800);
    }
  } else {
    for (const it of items) { delete it._detailUrl; }
  }
  return items;
}

function scrape(svc, genre, period, limit) {
  function clean(t) { return (t||"").replace(/\s+/g," ").trim(); }
  const results = [];

  // ===== ピッコマ =====
  if (svc === "piccoma") {
    const NAV = new Set(["無料作品","独占先行","曜日連載","新着","ランキング","キャンペーン","ヘルプ","ログイン","無料登録","少女/女性","少年/青年","TL","BL","ファンタジー","恋愛","ドラマ","アクション","スポーツ","グルメ","日常","お知らせ","ピッコマとは","ホーム","マンガ","SMARTOON","ノベル","総合","ホラー・ミステリー","裏社会・アングラ"]);
    const uls = [...document.querySelectorAll("ul")].filter(ul => ul.querySelectorAll("li").length >= 10);
    for (const ul of uls) {
      const tmp = [];
      for (const li of ul.querySelectorAll("li")) {
        if (tmp.length >= limit) break;
        const titleLink = li.querySelector("a[href*='/product/']");
        if (!titleLink) continue;
        let title = "";
        for (const sp of titleLink.querySelectorAll("span,p,h3,h4")) {
          const t = clean(sp.textContent);
          if (/^[\d,]+$/.test(t)||NAV.has(t)||t.length<2||t.length>120) continue;
          title = t; break;
        }
        if (!title) {
          let raw = clean(titleLink.textContent).replace(/^\d+\s*/,"").replace(/\s*[\d,]+$/,"").trim();
          if (raw.length>=2&&!NAV.has(raw)) title=raw;
        }
        if (!title||NAV.has(title)) continue;
        let author=""; let foundTitle=false;
        for (const sp of titleLink.querySelectorAll("span,p")) {
          const t=clean(sp.textContent);
          if (!t) continue;
          if (t===title){foundTitle=true;continue;}
          if (foundTitle&&!(/^[\d,]+$/.test(t))&&!NAV.has(t)&&t.length>=2&&t.length<=40){author=t;break;}
        }
        tmp.push({ rank:tmp.length+1, title, author, genre, period, publisher:"", label:"", tags:[], trend:"same", _detailUrl:titleLink.href||"" });
      }
      if (tmp.length>=5) return tmp;
    }
    const seen=new Set();
    document.querySelectorAll("a[href*='/product/']").forEach(a=>{
      if (results.length>=limit) return;
      const t=(a.getAttribute("title")||a.getAttribute("aria-label")||"").trim();
      if (!t||t.length<2||seen.has(t)||NAV.has(t)) return;
      seen.add(t);
      results.push({ rank:results.length+1, title:t, author:"", genre, period, publisher:"", label:"", tags:[], trend:"same", _detailUrl:a.href||"" });
    });
    return results;
  }

  // ===== シーモア =====
  if (svc === "seymour") {
    const SKIP = new Set(["購入ページへ","無料立読み","レビュー","お気に入り","立読み"]);
    const uls = [...document.querySelectorAll("ul")].filter(ul=>ul.querySelectorAll("a[href*='/title/']").length>=5);
    if (uls.length>0) {
      [...uls[0].querySelectorAll("li")].forEach((li,i)=>{
        if (i>=limit) return;
        const titleAnchor=[...li.querySelectorAll("a[href*='/title/']")].find(a=>clean(a.textContent).length>2&&!SKIP.has(clean(a.textContent)));
        if (!titleAnchor) return;
        const title=clean(titleAnchor.textContent);
        const liText=li.textContent;
        const authorM=liText.match(/作家[：:]\s*(.+?)(?:\s+ジャンル|　|\n)/);
        results.push({ rank:i+1, title,
          author:authorM?authorM[1].trim().replace(/\s+/g," "):"",
          genre, period, publisher:"", label:"", tags:[], trend:"same",
          _detailUrl:titleAnchor.href||"" });
      });
    }
    if (results.length<3) {
      const seen=new Set();
      document.querySelectorAll("a[href*='/title/']").forEach(a=>{
        if (results.length>=limit) return;
        const t=clean(a.textContent);
        if (!t||t.length<2||t.length>100||seen.has(t)||SKIP.has(t)) return;
        seen.add(t);
        results.push({ rank:results.length+1, title:t, author:"", genre, period, publisher:"", label:"", tags:[], trend:"same", _detailUrl:a.href||"" });
      });
    }
    return results;
  }

  // ===== ニコニコ漫画 =====
  // 構造: タイトルリンクの直前のテキストノード/要素に「作者:XXX」が記載
  // 例:
  //   作者:原作：伏瀬 漫画：川上泰樹
  //   <a href="/comic/18466?track=rank">転生したらスライムだった件</a>
  if (svc === "niconico") {
    const seen = new Set();
    const allLinks = [...document.querySelectorAll("a[href*='/comic/'][href*='track=rank']")];
    let rank = 0;
    for (const a of allLinks) {
      if (results.length >= limit) break;
      let t = (a.textContent||"").replace(/\s+/g," ").trim();
      if (/^\d+話/.test(t)||t.includes("pts")||t.includes("更新")||t.includes("最新の無料話")) continue;
      if (!t||t.length<2||t.length>100||seen.has(t)) continue;
      seen.add(t);
      rank++;
      // 作者取得: タイトルリンク（または親）から後ろ向きに遡って「作者:」を探す
      let author = "", label = "";
      
      // 戦略1: タイトルリンクを基点に、自身→親→親と上に登りつつ、
      // 各レベルで前の兄弟要素のテキストに「作者:」が含まれるかチェック
      function findAuthorText(startNode) {
        let cur = startNode;
        // 最大10階層まで親を遡る
        for (let depth = 0; depth < 10 && cur; depth++) {
          // 前の兄弟要素を最大15個まで探索
          let sibling = cur.previousSibling;
          let cnt = 0;
          while (sibling && cnt < 15) {
            const txt = (sibling.textContent || sibling.nodeValue || "").trim();
            if (txt.startsWith("作者:") || txt.startsWith("作者：")) {
              return txt;
            }
            // 「作者:」を含むテキストノードを発見
            const m = txt.match(/作者[：:]([^\n]{2,150})/);
            if (m) {
              // ただし複数作品の情報が混入している場合は最後の「作者:」を採用
              const lastIdx = txt.lastIndexOf("作者:");
              const lastIdx2 = txt.lastIndexOf("作者：");
              const idx = Math.max(lastIdx, lastIdx2);
              if (idx >= 0) {
                return txt.slice(idx);
              }
            }
            sibling = sibling.previousSibling;
            cnt++;
          }
          cur = cur.parentElement;
        }
        return "";
      }
      
      const authorRaw = findAuthorText(a);
      if (authorRaw) {
        // 「作者:」プレフィックスを除去
        let sub = authorRaw.replace(/^作者[：:]\s*/, "");
        // 後続の不要部分を切り捨て
        sub = sub.split(/[\n\r]/)[0];
        sub = sub.replace(/最新の無料話.*$/, "");
        sub = sub.replace(/第\d+話.*$/, "");
        sub = sub.replace(/\d+pts\..*$/, "");
        sub = sub.replace(/\d{4}年\d+月\d+日.*$/, "");
        sub = sub.replace(/\s+/g, " ").trim();
        author = sub;
      }
      
      // レーベル: /official/ リンク（近傍ブロック内）
      const block = a.closest("td") || a.closest("li") || a.closest("section") || a.closest("div[class]") || a.parentElement;
      if (block) {
        const officialLink = block.querySelector("a[href*='/official/']");
        if (officialLink) label = (officialLink.textContent||"").replace(/\[公式\]\s*/,"").replace(/\s*\d+\/\d+更新$/,"").trim();
      }
      // パンくずから雑誌名を取得（ページ上部）
      if (!label) {
        const breadcrumb = document.querySelector("nav li:nth-child(2) a, .breadcrumb li:nth-child(2) a");
        if (breadcrumb && breadcrumb.href && breadcrumb.href.includes("/official/")) {
          label = (breadcrumb.textContent||"").replace(/\[公式\]\s*/,"").trim();
        }
      }
      results.push({ rank, title:t, author, genre, period, publisher:"", label, tags:[], trend:"same" });
    }
    return results;
  }

  return results;
}

// シーモア作品詳細ページから出版社・レーベル取得（SSR）
function scrapeSeymourDetail() {
  function clean(t) { return (t||"").replace(/\s+/g," ").trim(); }
  let publisher="", label="";
  // パンくず: /search/publisher/ → 出版社, /search/magazine/ → レーベル
  document.querySelectorAll("a[href*='/search/publisher/']").forEach(a => { if(!publisher) publisher=clean(a.textContent); });
  document.querySelectorAll("a[href*='/search/magazine/']").forEach(a => { if(!label) label=clean(a.textContent); });
  // フォールバック: テキスト検索
  if (!publisher||!label) {
    const txt=document.body.innerText||"";
    if (!publisher) { const m=txt.match(/出版社[：:]\s*([^\n]{2,40})/); if(m) publisher=m[1].trim(); }
    if (!label)     { const m=txt.match(/レーベル[：:]\s*([^\n]{2,40})/); if(m) label=m[1].trim(); }
  }
  return { publisher, label };
}

function waitLoad(tabId) {
  return new Promise(resolve => {
    const fn=(id,info)=>{if(id===tabId&&info.status==="complete"){chrome.tabs.onUpdated.removeListener(fn);resolve();}};
    chrome.tabs.onUpdated.addListener(fn);
    setTimeout(()=>{chrome.tabs.onUpdated.removeListener(fn);resolve();},25000);
  });
}
function sleep(ms){return new Promise(r=>setTimeout(r,ms));}
let _statuses={};
async function patchStatus(key,text,type){_statuses[key]={text,type};await chrome.storage.local.set({statuses:{..._statuses}});}
