const RENTA_KEYS = [
  "renta_shounen_daily","renta_seinen_daily","renta_shoujo_daily","renta_josei_daily","renta_bl_daily","renta_tl_daily",
  "renta_shounen_monthly","renta_seinen_monthly","renta_shoujo_monthly","renta_josei_monthly","renta_bl_monthly","renta_tl_monthly"
];
const NICO_GENRES  = ["shounen","seinen","shoujo","josei"]; // bl/tl はニコニコ漫画に存在しない
const NICO_PERIODS = ["daily","monthly"];
const GENRE_LABELS = { shounen:"少年",seinen:"青年",shoujo:"少女",josei:"女性",bl:"BL",tl:"TL" };
const PERIOD_LABELS= { daily:"日間",monthly:"月間" };
const SVC_LABEL    = { piccoma:"ピッコマ",seymour:"シーモア",renta:"Renta!",niconico:"ニコニコ" };
const URL_STORE    = "manga_urls_v3";
const NICO_STORE   = "manga_nico_v3";

let polling = null;
let seyPeriods = new Set(["daily","monthly"]);
let limitVal = 30;

// ===== URL 永続化 =====
function saveUrls() {
  const urls = {};
  for (const k of RENTA_KEYS) { const el=document.getElementById(k); if(el&&el.value.trim()) urls[k]=el.value.trim(); }
  chrome.storage.local.set({ [URL_STORE]: urls });
}
function saveNico() {
  const cfg = {};
  for (const g of NICO_GENRES) for (const p of NICO_PERIODS) {
    const el = document.getElementById(`nico_${g}_${p}`);
    if (el&&el.checked) { if(!cfg[g]) cfg[g]=[]; cfg[g].push(p); }
  }
  chrome.storage.local.set({ [NICO_STORE]: cfg });
}
chrome.storage.local.get([URL_STORE, NICO_STORE], d => {
  const urls = d[URL_STORE]||{};
  for (const k of RENTA_KEYS) { const el=document.getElementById(k); if(el&&urls[k]) el.value=urls[k]; }
  const nico = d[NICO_STORE]||{};
  for (const g of NICO_GENRES) for (const p of NICO_PERIODS) {
    const el=document.getElementById(`nico_${g}_${p}`);
    if (el) el.checked = !!(nico[g]&&nico[g].includes(p));
  }
});
document.querySelectorAll('.url-in').forEach(el => el.addEventListener('blur', saveUrls));
document.querySelectorAll('.nico-chk input').forEach(el => el.addEventListener('change', saveNico));

// ===== シーモア期間タブ =====
document.querySelectorAll('.period-tabs .ptab').forEach(btn => {
  btn.addEventListener('click', () => {
    btn.classList.toggle('on');
    const p = btn.dataset.period;
    if (btn.classList.contains('on')) seyPeriods.add(p); else seyPeriods.delete(p);
  });
});

// ===== 取得件数 =====
document.querySelectorAll('.seg-btn[data-limit]').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.seg-btn[data-limit]').forEach(b => b.classList.remove('on'));
    btn.classList.add('on');
    limitVal = parseInt(btn.dataset.limit);
  });
});

// ===== チェック全選択/解除 =====
function setupToggle(toggleId, gridId) {
  const toggle=document.getElementById(toggleId), grid=document.getElementById(gridId);
  const update=()=>{ const all=[...grid.querySelectorAll('input')]; toggle.textContent=all.every(c=>c.checked)?'全解除':'全選択'; };
  toggle.addEventListener('click',()=>{ const all=[...grid.querySelectorAll('input')]; const next=!all.every(c=>c.checked); all.forEach(c=>c.checked=next); update(); });
  grid.addEventListener('change', update);
}
setupToggle('picToggle','picGrid');
setupToggle('seyToggle','seyGrid');

// ===== 選択キー収集 =====
function getSelectedKeys() {
  const keys = [...document.querySelectorAll('#picGrid input[data-key]:checked')].map(c=>c.dataset.key);
  [...document.querySelectorAll('#seyGrid input[data-key]:checked')].forEach(c => {
    const genre = c.dataset.key.replace('seymour_','');
    for (const p of seyPeriods) keys.push(`seymour_${genre}_${p}`);
  });
  return keys;
}
function getRentaUrls() {
  const urls={};
  for (const k of RENTA_KEYS) { const el=document.getElementById(k); if(el&&el.value.trim()) urls[k]=el.value.trim(); }
  return urls;
}
function getNiconicoConfig() {
  const cfg={};
  for (const g of NICO_GENRES) for (const p of NICO_PERIODS) {
    const el=document.getElementById(`nico_${g}_${p}`);
    if (el&&el.checked) { if(!cfg[g]) cfg[g]=[]; cfg[g].push(p); }
  }
  return cfg;
}

// ===== キー表示名 =====
function keyLabel(key) {
  const parts=key.split('_');
  const period=parts[parts.length-1];
  const svc=parts[0];
  const genre=parts.slice(1,-1).join('_');
  return `${SVC_LABEL[svc]||svc} ${GENRE_LABELS[genre]||genre} ${PERIOD_LABELS[period]||period}`;
}

// ===== 進捗表示 =====
function buildProgressRows(keys, rentaUrls, nicoCfg) {
  const container=document.getElementById('progressRows');
  container.innerHTML='';
  const allKeys=[
    ...Object.keys(rentaUrls),
    ...Object.entries(nicoCfg).flatMap(([g,ps])=>ps.map(p=>`niconico_${g}_${p}`)),
    ...keys
  ];
  for (const key of allKeys) {
    const row=document.createElement('div'); row.className='prow';
    row.innerHTML=`<span class="prow-label">${keyLabel(key)}</span><span class="prow-stat" id="ps-${key}">待機中</span>`;
    container.appendChild(row);
  }
}
function setStat(key,text,type) { const el=document.getElementById('ps-'+key); if(!el)return; el.textContent=text; el.className='prow-stat'+(type?' '+type:''); }
function setProgress(cur,total,msg) {
  document.getElementById('progBg').classList.toggle('on',total>0);
  document.getElementById('progFill').style.width=total>0?Math.round(cur/total*100)+'%':'0%';
  document.getElementById('progMsg').textContent=msg||'';
}
function applyState(data) {
  if(data.statuses) for(const[k,s] of Object.entries(data.statuses)) setStat(k,s.text,s.type);
  setProgress(data.step||0,data.total||0,data.msg||'');
  const btn=document.getElementById('btnFetch'), copyBtn=document.getElementById('btnCopy');
  if(data.running){ btn.disabled=true; btn.innerHTML='<span class="spinner"></span> 取得中...'; copyBtn.classList.remove('on'); }
  else { btn.disabled=false; btn.innerHTML=data.lastResult?'🔄 再取得':'ランキングを取得'; if(data.lastResult) copyBtn.classList.add('on'); }
}
function startPolling() {
  if(polling) return;
  polling=setInterval(()=>{ chrome.storage.local.get(['running','step','total','msg','statuses','lastResult'],data=>{ applyState(data); if(!data.running) stopPolling(); }); },600);
}
function stopPolling() { clearInterval(polling); polling=null; }

// ===== 取得ボタン =====
document.getElementById('btnFetch').addEventListener('click',()=>{
  const keys=getSelectedKeys();
  const rentaUrls=getRentaUrls();
  const nicoCfg=getNiconicoConfig();
  const fetchDetail=document.getElementById('fetchDetailChk').checked;
  saveUrls(); saveNico();
  buildProgressRows(keys,rentaUrls,nicoCfg);
  chrome.storage.local.set({running:false,step:0,total:0,msg:'',statuses:{},lastResult:null});
  document.getElementById('btnCopy').classList.remove('on');
  document.getElementById('copied').classList.remove('on');
  const btn=document.getElementById('btnFetch');
  btn.disabled=true; btn.innerHTML='<span class="spinner"></span> 取得中...';
  chrome.runtime.sendMessage({ type:'START_FETCH', selectedKeys:keys, rentaUrls, niconicoConfig:nicoCfg, limit:limitVal, fetchDetail });
  startPolling();
});

// ===== コピーボタン =====
document.getElementById('btnCopy').addEventListener('click',()=>{
  chrome.storage.local.get(['lastResult'],data=>{
    if(!data.lastResult) return;
    const json=JSON.stringify(data.lastResult,null,2);
    const showCopied=()=>{ const el=document.getElementById('copied'); el.classList.add('on'); setTimeout(()=>el.classList.remove('on'),3000); };
    navigator.clipboard.writeText(json).then(showCopied).catch(()=>{ const ta=document.createElement('textarea'); ta.value=json; document.body.appendChild(ta); ta.select(); document.execCommand('copy'); document.body.removeChild(ta); showCopied(); });
  });
});

// 起動時状態復元
chrome.storage.local.get(['running','step','total','msg','statuses','lastResult'],data=>{
  applyState(data);
  if(data.running) startPolling();
});
